from local_planners.local_planner import LocalPlanner
from geometry import Point, Vector, compute_direction, point_point_square_distance
# sensor data structure
from agents.agent import Agent, SimulatedPerception, Box2DPerception
# agent workflow
from agents.naive_agent import NaiveAgent
# environment type data structure
from representation.continous_space import ContinuousSpace
from representation.gridmap_a import GridmapWithNeighbors

from multiprocessing.connection import Listener, Client
from time import time, sleep

from math import sin, cos, sqrt, atan2


class P2PEvalLocal(LocalPlanner):
    """ This type of planner computes the linear velocity vector in which the agent will move during the next simulated step;
    The output MUST be a (float, float) tuple, each float stands for the speed in (x, y) direction respectively.

    Keyword arguments:
        position: the agent's current position <Point type>
        velocity: the agent's last velocity <tuple type: (x-float, y-float)>
        environment: the environment in which the agent works on
        sensor_observation: the sensor data obtained by the agent's sensor
        global_planner_path: list of poses (way points <Point type>) obtained from global planner
    Return:
        A (x-float, y-float) tuple
    """

    def __init__(self, agent):
        super(P2PEvalLocal, self).__init__(agent)

        agent_port = 6510 + 2 * self.agent.get_id()
        listener = Listener(('eval_simulator', agent_port), authkey=b'evaluate password plan')
        self.env_observation_conn = listener.accept()
        self.cycle_counter = 0
        self.modified = False

        while True:
            try:
                self.env_action_conn = Client(('agent', agent_port + 1), authkey=b'evaluate password action')
                break
            except:
                print 'Waiting for TF environment.'
                sleep(1)

    def compute_plan(self, position, velocity, environment, sensor_observation, global_planner_path):

        # try:
        #     # if the agent arrives the current point in global path, remove it and go for the next; else, go towards the current
        #     if position.arrive(global_planner_path[0]):
        #         global_planner_path.pop(0)
        #     goal_pose = global_planner_path[0]
        # except:  # if no further way point in global_path, move directly towards destination location
        #     goal_pose = self.agent.destination_location

        goal_pose = self.agent.destination_location
        self.agent.replan = True

        if self.cycle_counter % 12 != 0:
            self.cycle_counter += 1
            return velocity

        self.cycle_counter += 1

        if not self.modified:
            if len(self.agent.history_ray_length_list) < 13:
                lidar_observation = self.agent.history_ray_length_list[0] + self.agent.history_ray_length_list[0] + \
                                    self.agent.history_ray_length_list[-1]
            elif len(self.agent.history_ray_length_list) < 25:
                lidar_observation = self.agent.history_ray_length_list[0] + self.agent.history_ray_length_list[12] + \
                                    self.agent.history_ray_length_list[-1]
            else:
                lidar_observation = self.agent.history_ray_length_list[0] + self.agent.history_ray_length_list[12] + \
                                    self.agent.history_ray_length_list[24]

            rel_goal_pose = (goal_pose.x - position.x, goal_pose.y - position.y)
            velocity_vector = Vector(velocity[0], velocity[1])

            agent_clearance = self.agent.min_ray_length

            prev_velocity_vector = Vector(self.agent.prev_linear_velocity[0], self.agent.prev_linear_velocity[1])
            if prev_velocity_vector.norm() * velocity_vector.norm() < 0.01:
                turning = 0
            else:
                turning = abs(prev_velocity_vector.get_angle(velocity_vector))

            observation = (lidar_observation,
                           rel_goal_pose,
                           velocity,
                           turning,
                           agent_clearance,
                           self.agent.total_collision)

            self.env_observation_conn.send(observation)
        action = self.env_action_conn.recv()

        new_velocity = Vector(action[0], action[1])
        new_speed = new_velocity.norm()
        new_velocity = new_velocity.scale(min(1.5 / new_speed, 1))

        return new_velocity.x, new_velocity.y

import numpy as np
import reverb
import tempfile
import sys
import os

import tensorflow as tf
from tensorflow.keras.optimizers import Adam

from tf_agents.agents import DdpgAgent
from tf_agents.agents.ddpg.critic_network import CriticNetwork
from tf_agents.agents.ddpg.actor_network import ActorNetwork

from tf_agents.drivers.py_driver import PyDriver

from tf_agents.environments import py_environment
from tf_agents.environments.utils import validate_py_environment

from tf_agents.metrics import tf_metrics

from tf_agents.networks.utils import mlp_layers

from tf_agents.policies.policy_saver import PolicySaver
from tf_agents.policies.random_py_policy import RandomPyPolicy
from tf_agents.policies.py_tf_eager_policy import PyTFEagerPolicy

from tf_agents.replay_buffers.reverb_replay_buffer import ReverbReplayBuffer, make_reverb_dataset

from tf_agents.specs import array_spec, tensor_spec

from tf_agents.train.utils import train_utils, strategy_utils
from tf_agents.train.actor import Actor, collect_metrics, eval_metrics

from tf_agents.trajectories import time_step as ts
from tf_agents.trajectories import Trajectory
from tf_agents.trajectories import StepType

from tf_agents.typing import types

from tf_agents.utils import common

from multiprocessing.connection import Connection, _ForkingPickler, Client, Listener

from math import pi
import re
from random import randint
import json
from time import sleep, time
import logging
import zipfile
import shutil

import google.cloud
from google.cloud import storage


def send_py2(self, obj):
    self._check_closed()
    self._check_writable()
    self._send_bytes(_ForkingPickler.dumps(obj, protocol=2))


def recv_py2(self):
    self._check_closed()
    self._check_readable()
    buf = self._recv_bytes()
    return _ForkingPickler.loads(buf.getbuffer(), encoding='latin1')


Connection.send = send_py2
Connection.recv = recv_py2

rl_config = {'buffer': {'initial_priority': 1.0,
                        'alpha': 0.6,
                        'beta_0': 0.5,
                        'eps': 1e-6},
             'ddpg': {'actor_lr': 1e-4,
                      'critic_lr': 1e-3,
                      'target_update_tau': 0.01,
                      'target_update_period': 1,
                      'gamma': 0.99,
                      'agent_batch_size': 8},
             'train': {'initial_collect_episode': 1,
                       'collect_step_per_iteration': 1,
                       'train_step_per_iteration': 16,
                       'num_train_iteration': 2000000,
                       'val_interval': 2000000,
                       'num_val_episode': 10}}

logging.basicConfig(filename='./src/main.log', level=logging.INFO, filemode='w')


class DorabotP2PTrainEnv(py_environment.PyEnvironment):
    listener = Listener(('agent', 6000), authkey=b'secret password')
    env_conn = listener.accept()

    @property
    def batched(self):
        return self._batched

    @property
    def batch_size(self):
        return self._batch_size

    def __init__(self, training_episode_config, reward_param):
        super(DorabotP2PTrainEnv, self).__init__()
        self.num_agent = training_episode_config['num_agent']
        self.env_observation_conns = []
        self.env_action_conns = []

        if self.num_agent > 1:
            self._batched = True
            self._batch_size = self.num_agent
        else:
            self._batched = False
            self._batch_size = None

        for i in range(self.num_agent):
            while True:
                try:
                    obs_port = 6010 + 2 * i
                    obs_conn = Client(('training_simulator', obs_port), authkey=b'secret password plan')
                    self.env_observation_conns.append(obs_conn)
                    break
                except:
                    sleep(1)

            act_port = 6011 + 2 * i
            act_listener = Listener(('agent', act_port), authkey=b'secret password action')
            self.env_action_conns.append(act_listener.accept())

        self._action_spec = array_spec.BoundedArraySpec(shape=(2,),
                                                        dtype=np.float32,
                                                        minimum=[-1.5, -1.5],
                                                        maximum=[1.5, 1.5])
        # lidar: 64 * 3, goal: 2, velocity: 2
        self._observation_spec = array_spec.BoundedArraySpec(shape=(64 * 3 + 2 + 2,),
                                                             dtype=np.float32,
                                                             minimum=([-1.0] * 64 * 3 +
                                                                      [np.finfo(np.float32).min] * 2 +
                                                                      [-1.5] * 2),
                                                             maximum=([1.0] * 64 * 3 +
                                                                      [np.finfo(np.float32).max] * 2 +
                                                                      [1.5] * 2))

        self._episode_ended = False
        # Reward = (step, goal_distance, goal, turning, clearance, collision)
        self.reward_param = np.array(reward_param)

        self.max_episode = training_episode_config['max_episode']
        self.episode_count = 0
        self.episode_length = training_episode_config['episode_length_sec'] * 5
        self.step_count = 0

        self.reset_handle_flag = False

        DorabotP2PTrainEnv.env_conn.send([training_episode_config['episode_length_sec'], self.max_episode,
                                          self.num_agent])

    def action_spec(self):
        return self._action_spec

    def observation_spec(self):
        return self._observation_spec

    def _reset(self):
        if self.max_episode == self.episode_count:
            # Return empty observation so not to invoke a new episode
            return ts.restart(np.zeros(self.observation_spec().shape), batch_size=self.num_agent)

        if self.reset_handle_flag:
            for i in range(self.num_agent):
                self.env_action_conns[i].send((0, 0))
            DorabotP2PTrainEnv.env_conn.send(True)
            self.episode_count += 1

            print(f'Number of episode completed: {self.episode_count}')
            print(f'Number of steps taken: {self.step_count}')

        self._episode_ended = False
        self.step_count = 0

        batch_restart_observation = []
        for observation_conn in self.env_observation_conns:
            restart_raw_observation = observation_conn.recv()
            restart_observation, _ = self._convert_raw_observation(restart_raw_observation)
            batch_restart_observation.append(restart_observation)
        self.reset_handle_flag = True

        print('-------------------------------------------')
        print(f'Starting episode: {self.episode_count + 1}')

        return ts.restart(np.concatenate(batch_restart_observation), batch_size=self.num_agent)

    def _step(self, actions):
        if self._episode_ended:
            return self.reset()

        if tf.is_tensor(actions):
            actions = actions.numpy().tolist()

        for i in range(self.num_agent):
            self.env_action_conns[i].send((actions[i][0], actions[i][1]))
        DorabotP2PTrainEnv.env_conn.send(False)
        batch_observation = []
        batch_reward = []
        for observation_conn in self.env_observation_conns:
            raw_observation = observation_conn.recv()
            observation, reward = self._convert_raw_observation(raw_observation)
            batch_observation.append(observation)
            batch_reward.append(reward)
        self.step_count += 1

        if self.step_count == self.episode_length:
            self._episode_ended = True
            for i in range(self.num_agent):
                self.env_action_conns[i].send((0, 0))
            DorabotP2PTrainEnv.env_conn.send(True)
            self.episode_count += 1

            print(f'Number of episode completed: {self.episode_count}')
            print(f'Number of steps taken: {self.step_count}')

            if self.max_episode == self.episode_count:
                for i in range(self.num_agent):
                    self.env_action_conns[i].close()

            self.reset_handle_flag = False

            output = ts.TimeStep(step_type=np.array([StepType.LAST] * self.num_agent),
                                 reward=np.array(batch_reward, dtype=np.float32),
                                 discount=np.ones(self.num_agent, dtype=np.float32),
                                 observation=np.concatenate(batch_observation))
        else:
            output = ts.TimeStep(step_type=np.array([StepType.MID] * self.num_agent),
                                 reward=np.array(batch_reward, dtype=np.float32),
                                 discount=np.ones(self.num_agent, dtype=np.float32),
                                 observation=np.concatenate(batch_observation))

        return output

    def _convert_raw_observation(self, raw_obs):
        # raw_obs[0] lidar : [64 * 3]
        # raw_obs[1] rel_goal_pose: (2,)
        # raw_obs[2] velocity: (2, )
        # raw_obs[3] turning: 1
        # raw_obs[4] agent_clearance: 1
        # raw_obs[5] collision: 1
        scale_lidar = [(i - 2) / 4 for i in raw_obs[0]]
        observation = np.array(scale_lidar + list(raw_obs[1]) + list(raw_obs[2]), dtype=np.float32).reshape(1, -1)
        goal_distance = np.linalg.norm(raw_obs[1])
        raw_reward = np.array([1,
                               goal_distance,
                               goal_distance < 5e-1,
                               abs(raw_obs[3]) / pi,
                               raw_obs[4],
                               raw_obs[5]], dtype=np.float32)
        reward = np.dot(self.reward_param, raw_reward)
        return observation, reward


class DorabotP2PEvalEnv(py_environment.PyEnvironment):
    listener = Listener(('agent', 6500), authkey=b'evaluate password')
    env_conn = listener.accept()

    @property
    def batched(self):
        return self._batched

    @property
    def batch_size(self):
        return self._batch_size

    def __init__(self, eval_episode_config, goal_threshold):
        super(DorabotP2PEvalEnv, self).__init__()
        self.num_agent = eval_episode_config['num_agent']
        self.env_observation_conns = []
        self.env_action_conns = []

        if self.num_agent > 1:
            self._batched = True
            self._batch_size = self.num_agent
        else:
            self._batched = False
            self._batch_size = None

        for i in range(self.num_agent):
            while True:
                try:
                    obs_port = 6510 + 2 * i
                    obs_conn = Client(('eval_simulator', obs_port), authkey=b'evaluate password plan')
                    self.env_observation_conns.append(obs_conn)
                    break
                except:
                    print(f'Waiting for P2PLocal of agent {i}.')
                    sleep(1)

            act_port = 6511 + 2 * i
            act_listener = Listener(('agent', act_port), authkey=b'evaluate password action')
            self.env_action_conns.append(act_listener.accept())

        self._action_spec = array_spec.BoundedArraySpec(shape=(2,),
                                                        dtype=np.float32,
                                                        minimum=[-1.5, -1.5],
                                                        maximum=[1.5, 1.5])
        # lidar: 64 * 3, goal: 2, velocity: 2
        self._observation_spec = array_spec.BoundedArraySpec(shape=(64 * 3 + 2 + 2,),
                                                             dtype=np.float32,
                                                             minimum=([-1.0] * 64 * 3 +
                                                                      [np.finfo(np.float32).min] * 2 +
                                                                      [-1.5] * 2),
                                                             maximum=([1.0] * 64 * 3 +
                                                                      [np.finfo(np.float32).max] * 2 +
                                                                      [1.5] * 2))

        self._episode_ended = False

        self.goal_threshold = goal_threshold
        self.max_episode = eval_episode_config['max_episode']
        self.episode_count = 0
        self.episode_length = eval_episode_config['episode_length_sec'] * 5
        self.step_count = 0

        self.reset_handle_flag = False

        DorabotP2PEvalEnv.env_conn.send([eval_episode_config['episode_length_sec'], self.max_episode,
                                         self.num_agent])

    def action_spec(self):
        return self._action_spec

    def observation_spec(self):
        return self._observation_spec

    def _reset(self):
        if self.max_episode == self.episode_count:
            # Return empty observation so not to invoke a new episode
            return ts.restart(np.zeros(self.observation_spec().shape), batch_size=self.num_agent)

        if self.reset_handle_flag:
            for i in range(self.num_agent):
                self.env_action_conns[i].send((0, 0))
            DorabotP2PEvalEnv.env_conn.send(True)
            self.episode_count += 1

            print(f'Number of episode completed: {self.episode_count}')
            print(f'Number of steps taken: {self.step_count}')

        self._episode_ended = False
        self.step_count = 0

        batch_restart_observation = []
        for observation_conn in self.env_observation_conns:
            restart_raw_observation = observation_conn.recv()
            restart_observation, _ = self._convert_raw_observation(restart_raw_observation)
            batch_restart_observation.append(restart_observation)
        self.reset_handle_flag = True

        print('-------------------------------------------')
        print(f'Starting episode: {self.episode_count + 1}')

        return ts.restart(np.concatenate(batch_restart_observation), batch_size=self.num_agent)

    def _step(self, actions):
        if self._episode_ended:
            return self.reset()

        if tf.is_tensor(actions):
            actions = actions.numpy().tolist()

        for i in range(self.num_agent):
            self.env_action_conns[i].send((actions[i][0], actions[i][1]))
        DorabotP2PEvalEnv.env_conn.send(False)
        batch_observation = []
        batch_reward = []
        for observation_conn in self.env_observation_conns:
            raw_observation = observation_conn.recv()
            observation, reward = self._convert_raw_observation(raw_observation)
            batch_observation.append(observation)
            batch_reward.append(reward)
        self.step_count += 1

        if self.step_count == self.episode_length:
            self._episode_ended = True
            for i in range(self.num_agent):
                self.env_action_conns[i].send((0, 0))
            DorabotP2PEvalEnv.env_conn.send(True)
            self.episode_count += 1

            print(f'Number of episode completed: {self.episode_count}')
            print(f'Number of steps taken: {self.step_count}')

            if self.max_episode == self.episode_count:
                for i in range(self.num_agent):
                    self.env_action_conns[i].close()

            self.reset_handle_flag = False

            output = ts.TimeStep(step_type=np.array([StepType.LAST] * self.num_agent),
                                 reward=np.array(batch_reward, dtype=np.float32),
                                 discount=np.ones(self.num_agent, dtype=np.float32),
                                 observation=np.concatenate(batch_observation))
        else:
            output = ts.TimeStep(step_type=np.array([StepType.MID] * self.num_agent),
                                 reward=np.array(batch_reward, dtype=np.float32),
                                 discount=np.ones(self.num_agent, dtype=np.float32),
                                 observation=np.concatenate(batch_observation))

        return output

    def _convert_raw_observation(self, raw_obs):
        # raw_obs[0] lidar : [64 * 3]
        # raw_obs[1] rel_goal_pose: (2,)
        # raw_obs[2] velocity: (2, )
        # raw_obs[3] turning: 1 NOT USED
        # raw_obs[4] agent_clearance: 1 NOT USED
        # raw_obs[5] total_collision: 1
        scale_lidar = [(i - 2) / 4 for i in raw_obs[0]]
        observation = np.array(scale_lidar + list(raw_obs[1]) + list(raw_obs[2]), dtype=np.float32).reshape(1, -1)
        goal_distance = np.linalg.norm(raw_obs[1])

        true_objective = int(goal_distance < self.goal_threshold)
        true_objective_reward = true_objective / (raw_obs[5] * 0.5 + 1)
        return observation, true_objective_reward


class ReverbBatchStepObserver(object):
    def __init__(self, py_client, table_name, batch_size, priority):
        self._table_names = [table_name]
        self._priority = priority
        self._batch_size = batch_size
        self._py_client = py_client
        self._writer = py_client.trajectory_writer(num_keep_alive_refs=batch_size + 1)
        self._cached_steps = 0
        self._last_batch_trajectory = None

    def __call__(self, batch_trajectory: Trajectory):
        self._last_batch_trajectory = batch_trajectory
        for i in range(self._batch_size):
            traj = Trajectory(step_type=batch_trajectory.step_type[i],
                              observation=tf.squeeze(batch_trajectory.observation[i, :]),
                              action=tf.squeeze(batch_trajectory.action[i, :]),
                              policy_info=batch_trajectory.policy_info,
                              next_step_type=batch_trajectory.next_step_type[i],
                              reward=batch_trajectory.reward[i],
                              discount=batch_trajectory.discount[i])
            self._writer.append(traj)
            self._cached_steps += 1
            self._write_cached_steps()
        if batch_trajectory.is_boundary().all():
            self.reset()
        return

    def _sequence_lengths_reached(self):
        return self._cached_steps >= self._batch_size + 1

    def _write_cached_steps(self):
        if self._sequence_lengths_reached():
            trajectory = tf.nest.map_structure(lambda d: d[[-self._batch_size, -1]], self._writer.history)
            for table_name in self._table_names:
                self._writer.create_item(table=table_name,
                                         trajectory=trajectory,
                                         priority=self._priority.numpy())
        return None

    def flush(self):
        self._writer.flush()

    def reset(self):
        self._cached_steps = 0
        self._last_batch_trajectory = None
        if self._writer is None:
            self.open()
        else:
            self._writer.end_episode(timeout_ms=1000)

    def open(self):
        if self._writer is None:
            self._writer = self._py_client.trajectory_writer(num_keep_alive_refs=self._batch_size + 1)
            self._cached_steps = 0

    def close(self):
        if self._writer is not None:
            self._writer.end_episode(timeout_ms=1000)
            self._writer.close()
            self._writer = None


def train_agent(training_episode_config, reward_param, priority_alpha, actor_fc_param, critic_obs_fc_param,
                critic_joint_fc_param):

    if reverb_client.server_info()[table_name].current_size != 0:
        raise ValueError('Reverb table not properly reset.')

    tempdir = tempfile.gettempdir()
    checkpoint_dir = os.path.join(tempdir, 'checkpoint')
    prev_t = 0
    zip_checkpoint = list_blobs_with_prefix(gcloud_bucket_name,
                                            f"reward_trial/saved_model/docker_{DOCKER_ID}_trial_{reward_param_json['current_trial']}_step")
    if zip_checkpoint:
        prev_t = re.search('step_(.*).zip', zip_checkpoint[0], re.IGNORECASE).group(1)
        prev_t = int(prev_t) + 1
        download_blob(gcloud_bucket_name,
                      zip_checkpoint[0],
                      os.path.join(tempdir, 'exported_cp.zip'))
        zip_file = zipfile.ZipFile(os.path.join(tempdir, 'exported_cp.zip'), 'r')
        zip_file.extractall(checkpoint_dir)
        zip_file.close()

    strategy = strategy_utils.get_strategy(tpu=False, use_gpu=False)

    logging.info(
        f"Starting trial {reward_param_json['current_trial']} on Docker {DOCKER_ID}, at train step {prev_t}.\n" +
        f"Reward parameters are {reward_param}")

    training_episode_config['max_episode'] -= prev_t / (training_episode_config['episode_length_sec'] * 5)
    training_episode_config['max_episode'] -= prev_t / rl_config['train']['val_interval'] * rl_config['train']['num_val_episode']

    py_env = DorabotP2PTrainEnv(training_episode_config, reward_param)
    time_step_spec = py_env.time_step_spec()
    observation_spec = time_step_spec.observation
    action_spec = py_env.action_spec()
    flat_action_spec = tf.nest.flatten(tensor_spec.from_spec(action_spec))

    with strategy.scope():
        actor_net = ActorNetwork(observation_spec, action_spec,
                                 fc_layer_params=actor_fc_param)
        kernel_initializer = tf.compat.v1.keras.initializers.VarianceScaling(scale=1. / 3.,
                                                                             mode='fan_in',
                                                                             distribution='uniform')
        last_kernel_initializer = tf.keras.initializers.RandomUniform(minval=-0.003, maxval=0.003)
        new_actor_mlp_layers = mlp_layers(None,
                                          actor_fc_param,
                                          None,
                                          activation_fn=tf.keras.activations.relu,
                                          kernel_initializer=kernel_initializer,
                                          weight_decay_params=[1e-2] * len(actor_fc_param),
                                          name='input_mlp')
        new_actor_mlp_layers.append(tf.keras.layers.Dense(flat_action_spec[0].shape.num_elements(),
                                                          activation=tf.keras.activations.tanh,
                                                          kernel_initializer=last_kernel_initializer,
                                                          kernel_regularizer=tf.keras.regularizers.L2(0.01),
                                                          name='action'))
        actor_net._mlp_layers = new_actor_mlp_layers

        critic_net = CriticNetwork((observation_spec, action_spec),
                                   observation_fc_layer_params=critic_obs_fc_param,
                                   joint_fc_layer_params=critic_joint_fc_param)
        critic_net._observation_layers = mlp_layers(None,
                                                    critic_obs_fc_param,
                                                    None,
                                                    activation_fn=tf.keras.activations.relu,
                                                    kernel_initializer=kernel_initializer,
                                                    weight_decay_params=[1e-2] * len(critic_obs_fc_param),
                                                    name='observation_encoding')
        new_critic_joint_layers = mlp_layers(None,
                                             critic_joint_fc_param,
                                             None,
                                             activation_fn=tf.keras.activations.relu,
                                             kernel_initializer=kernel_initializer,
                                             weight_decay_params=[1e-2] * len(critic_joint_fc_param),
                                             name='joint_mlp')
        new_critic_joint_layers.append(tf.keras.layers.Dense(1,
                                                             kernel_initializer=last_kernel_initializer,
                                                             kernel_regularizer=tf.keras.regularizers.L2(0.01),
                                                             name='value'))
        critic_net._joint_layers = new_critic_joint_layers

        train_step = train_utils.create_train_step()

        tf_agent = DdpgAgent(time_step_spec,
                             action_spec,
                             actor_network=actor_net,
                             critic_network=critic_net,
                             actor_optimizer=Adam(learning_rate=rl_config['ddpg']['actor_lr']),
                             critic_optimizer=Adam(learning_rate=rl_config['ddpg']['critic_lr']),
                             ou_stddev=0.2,
                             ou_damping=0.15,
                             target_update_tau=rl_config['ddpg']['target_update_tau'],
                             target_update_period=rl_config['ddpg']['target_update_period'],
                             gamma=rl_config['ddpg']['gamma'],
                             train_step_counter=train_step)

        def modified_actor_loss(self,
                                time_steps: ts.TimeStep,
                                weights: None,
                                training: bool = False):
            """Computes the actor_loss for DDPG training.

            Args:
              time_steps: A batch of timesteps.
              weights: Optional scalar or element-wise (per-batch-entry) importance
                weights.
              training: Whether this loss is being used for training.
              # TODO(b/124383618): Add an action norm regularizer.
            Returns:
              actor_loss: A scalar actor loss.
            """
            from tf_agents.utils import nest_utils
            with tf.name_scope('actor_loss'):
                actions, _ = self._actor_network(time_steps.observation,
                                                 step_type=time_steps.step_type,
                                                 training=training)
                with tf.GradientTape(watch_accessed_variables=False) as tape:
                    tape.watch(actions)
                    q_values, _ = self._critic_network((time_steps.observation, actions),
                                                       step_type=time_steps.step_type,
                                                       training=False)
                    actions = tf.nest.flatten(actions)

                dqdas = tape.gradient([q_values], actions)

                actor_losses = []
                for dqda, action in zip(dqdas, actions):
                    if self._dqda_clipping is not None:
                        dqda = tf.clip_by_value(dqda, -1 * self._dqda_clipping,
                                                self._dqda_clipping)
                    loss = common.element_wise_squared_loss(
                        tf.stop_gradient(dqda + action), action)
                    if nest_utils.is_batched_nested_tensors(
                            time_steps, self.time_step_spec, num_outer_dims=2):
                        # Sum over the time dimension.
                        loss = tf.reduce_sum(loss, axis=1)
                    # if weights is not None:
                    #     loss *= weights
                    loss = tf.reduce_mean(loss)
                    actor_losses.append(loss)

                actor_loss = tf.add_n(actor_losses)

                with tf.name_scope('Losses/'):
                    tf.compat.v2.summary.scalar(
                        name='actor_loss', data=actor_loss, step=self.train_step_counter)

            return actor_loss

        tf_agent.actor_loss = modified_actor_loss.__get__(tf_agent)

        def elementwise_td_error(self,
                                 experience: Trajectory):
            transition = self._as_transition(experience)
            time_steps, policy_steps, next_time_steps = transition
            actions = policy_steps.action
            with tf.name_scope('elementwise_td_error'):
                target_actions, _ = self._target_actor_network(
                    next_time_steps.observation, step_type=next_time_steps.step_type,
                    training=False)
                target_critic_net_input = (next_time_steps.observation, target_actions)
                target_q_values, _ = self._target_critic_network(
                    target_critic_net_input, step_type=next_time_steps.step_type,
                    training=False)

                td_targets = tf.stop_gradient(
                    self._reward_scale_factor * next_time_steps.reward +
                    self._gamma * next_time_steps.discount * target_q_values)

                critic_net_input = (time_steps.observation, actions)
                q_values, _ = self._critic_network(critic_net_input,
                                                   step_type=time_steps.step_type,
                                                   training=False)

                td_error = tf.math.minimum(tf.math.abs(td_targets - q_values), tf.constant(1, tf.float32))
                return td_error

        tf_agent.elementwise_td_error = elementwise_td_error.__get__(tf_agent)

    tf_agent.initialize()
    tf_agent.train = common.function(tf_agent.train)
    tf_agent.elementwise_td_error = common.function(tf_agent.elementwise_td_error)

    with strategy.scope():
        max_priority = tf.Variable(initial_value=tf.constant(rl_config['buffer']['initial_priority'], dtype=tf.float32),
                                   trainable=False,
                                   name='max_priority')
        max_priority_count = tf.Variable(initial_value=(rl_config['train']['initial_collect_episode'] *
                                                        training_episode_config['num_agent'] *
                                                        training_episode_config['episode_length_sec'] * 5),
                                         trainable=False,
                                         name='curr_max_priority_count',
                                         dtype=tf.int32)
        prev_max_priority = tf.Variable(initial_value=tf.constant(0, dtype=tf.float32),
                                        trainable=False,
                                        name='prev_max_priority')
        prev_max_priority_count = tf.Variable(initial_value=tf.constant(0, dtype=tf.int32),
                                              trainable=False,
                                              name='prev_max_priority_count')
        min_priority = tf.Variable(initial_value=tf.constant(rl_config['buffer']['initial_priority'], dtype=tf.float32),
                                   trainable=False,
                                   name='min_priority')
        batch_eps = tf.constant(rl_config['buffer']['eps'], shape=(rl_config['ddpg']['agent_batch_size'],),
                                dtype=tf.float32)

    reverb_batch_observer = ReverbBatchStepObserver(reverb_client, table_name,
                                                    training_episode_config['num_agent'],
                                                    max_priority)

    initial_collect_policy = RandomPyPolicy(time_step_spec, action_spec)
    initial_collect_actor = Actor(py_env,
                                  initial_collect_policy,
                                  train_step,
                                  episodes_per_run=rl_config['train']['initial_collect_episode'],
                                  observers=[reverb_batch_observer])

    env_steps = tf_metrics.EnvironmentSteps(prefix='Train')

    if env_steps.result() == 0:
        logging.info(
            f'Initializing replay buffer by collecting experience for {rl_config["train"]["initial_collect_episode"]}' +
            ' episode with a random policy.')
        initial_collect_actor.run()

    collect_policy = PyTFEagerPolicy(tf_agent.collect_policy, use_tf_function=True, batch_time_steps=False)
    collect_driver = PyDriver(py_env,
                              policy=collect_policy,
                              observers=[reverb_batch_observer, env_steps],
                              max_steps=rl_config['train']['collect_step_per_iteration'],
                              max_episodes=1)

    val_policy = PyTFEagerPolicy(tf_agent.policy, use_tf_function=True, batch_time_steps=False)
    val_metrics = eval_metrics(rl_config['train']['num_val_episode'])
    val_driver = PyDriver(py_env,
                          policy=val_policy,
                          observers=val_metrics,
                          max_episodes=rl_config['train']['num_val_episode'] * training_episode_config['num_agent'])

    time_acc = 0
    env_steps_before = env_steps.result().numpy()

    reverb_replay = ReverbReplayBuffer(tf_agent.collect_data_spec,
                                       sequence_length=2,
                                       table_name=table_name,
                                       local_server=reverb_server,
                                       dataset_buffer_size=3 * rl_config['ddpg']['agent_batch_size'])
    dataset = reverb_replay.as_dataset(num_parallel_calls=3,
                                       sample_batch_size=rl_config['ddpg']['agent_batch_size'],
                                       num_steps=2).prefetch(3 * rl_config['ddpg']['agent_batch_size'])
    iterator = iter(dataset)

    @tf.function
    def train_and_update_priority():
        experience, info = next(iterator)

        td_error = tf_agent.elementwise_td_error(experience)
        priority_ratio = (tf.broadcast_to(min_priority, shape=(rl_config['ddpg']['agent_batch_size'],)) /
                          tf.cast(info.priority[:, 0], dtype=tf.float32))
        beta = (rl_config['buffer']['beta_0'] +
                (1 - rl_config['buffer']['beta_0']) * t / rl_config['train']['num_train_iteration'])
        imp_sample_exponent = priority_alpha * beta
        imp_sample_weight = priority_ratio ** imp_sample_exponent
        loss_info = tf_agent.train(experience, weights=imp_sample_weight)
        priority = td_error + batch_eps
        # priority_update = dict(*zip(info.key[:, 0].numpy().tolist(), priority.numpy().tolist()))
        # reverb_client.mutate_priorities(table=table_name, updates=priority_update)
        reverb_replay.update_priorities(info.key[:, 0], tf.cast(priority, dtype=tf.float64))
        iter_max_priority = tf.reduce_max(priority)
        iter_min_priority = tf.reduce_min(priority)

        max_priority_count.assign_sub(tf.math.reduce_sum(tf.cast(tf.math.equal(tf.cast(info.priority[:, 0],
                                                                                       dtype=tf.float32),
                                                                               max_priority),
                                                                 dtype=tf.int32)))

        if tf.math.less_equal(max_priority_count, tf.constant(0, dtype=tf.int32)):
            if tf.math.greater(prev_max_priority, iter_max_priority):
                max_priority.assign(prev_max_priority)
                max_priority_count.assign(prev_max_priority_count)
                prev_max_priority.assign(iter_max_priority)
                prev_max_priority_count.assign(tf.math.reduce_sum(tf.cast(tf.math.equal(priority, iter_max_priority),
                                                                          dtype=tf.int32)))
            else:
                max_priority.assign(iter_max_priority)
                max_priority_count.assign(tf.math.reduce_sum(tf.cast(tf.math.equal(priority, iter_max_priority),
                                                                     dtype=tf.int32)))
        elif tf.math.greater(iter_max_priority, max_priority):
            prev_max_priority.assign(max_priority)
            prev_max_priority_count.assign(max_priority_count)
            max_priority.assign(iter_max_priority)
            max_priority_count.assign(tf.math.reduce_sum(tf.cast(tf.math.equal(priority, iter_max_priority),
                                                                 dtype=tf.int32)))
        elif tf.math.greater(iter_max_priority, prev_max_priority):
            prev_max_priority.assign(iter_max_priority)
            prev_max_priority_count.assign(tf.math.reduce_sum(tf.cast(tf.math.equal(priority, iter_max_priority),
                                                                      dtype=tf.int32)))
        min_priority.assign(tf.math.minimum(min_priority, iter_min_priority))

    train_checkpointer = common.Checkpointer(ckpt_dir=checkpoint_dir,
                                             max_to_keep=1,
                                             agent=tf_agent,
                                             policy=tf_agent.policy,
                                             replay_buffer=reverb_replay,
                                             global_step=train_step)

    train_checkpointer.initialize_or_restore()
    policy_dir = os.path.join(tempdir, 'policy')
    tf_policy_saver = PolicySaver(tf_agent.policy)

    time_step = py_env.current_time_step()
    curr_train_step = int(train_step.numpy())
    logging.info(f"prev_t {prev_t} curr_train_step {curr_train_step}")
    for t in range(curr_train_step // rl_config['train']['train_step_per_iteration'],
                   rl_config['train']['num_train_iteration']):
        start_time = time()

        if time_step.is_first().all():
            time_step, _ = collect_driver.run(time_step=time_step)
        time_step, _ = collect_driver.run(time_step=time_step)
        max_priority_count.assign_add(training_episode_config['num_agent'])

        for _ in range(rl_config['train']['train_step_per_iteration']):
            train_and_update_priority()
        time_acc += time() - start_time

        if train_step.numpy() % (rl_config['train']['val_interval'] * training_episode_config["num_agent"]) == 0:
            logging.info(f'batch env steps = {env_steps.result() / training_episode_config["num_agent"]}')
            env_steps_per_sec = (env_steps.result().numpy() - env_steps_before) / (time_acc *
                                                                                   training_episode_config["num_agent"])
            logging.info(f'{env_steps_per_sec:.3f} batch env steps/sec')
            logging.info(f'Train step: {train_step.numpy()}')

            if not time_step.is_first().all():
                raise ValueError('Misalignment before validation')

            time_step, _ = val_driver.run(time_step=time_step)

            if not time_step.is_first().all():
                raise ValueError('Misalignment after validation')

            val_results = {}
            for metric in val_metrics:
                val_results[metric.name] = metric.result()
            logging.info(', '.join(f'{name} = {result:.6f}' for name, result in val_results.items()))

            train_checkpointer.save(train_step)
            checkpoint_zip_filename = create_zip_file(checkpoint_dir,
                                                      os.path.join(tempdir, 'exported_cp'))
            upload_blob(gcloud_bucket_name, checkpoint_zip_filename,
                        f"reward_trial/saved_model/docker_{DOCKER_ID}_trial_{reward_param_json['current_trial']}_step_{t}.zip")
            if train_step.numpy() // (rl_config['train']['val_interval'] * training_episode_config["num_agent"]) > 1:
                delete_blob(gcloud_bucket_name,
                            f"reward_trial/saved_model/docker_{DOCKER_ID}_trial_{reward_param_json['current_trial']}_step_{t - rl_config['train']['val_interval']}.zip")

            time_acc = 0
            env_steps_before = env_steps.result().numpy()

        if t == rl_config['train']['num_train_iteration'] - 1:
            sleep(10)
            shutil.rmtree(checkpoint_dir)

    reverb_batch_observer.close()

    tf_policy_saver.save(policy_dir)

    eval_episode_config = {'num_agent': training_episode_config['num_agent'],
                           'episode_length_sec': 100,
                           'max_episode': 100}
    py_eval_env = DorabotP2PEvalEnv(eval_episode_config, goal_threshold=1)
    eval_actor = Actor(py_eval_env,
                       val_policy,
                       train_step,
                       episodes_per_run=eval_episode_config['max_episode'] * eval_episode_config['num_agent'],
                       metrics=eval_metrics(eval_episode_config['max_episode']))
    eval_actor.run()
    eval_results = {}
    for metric in eval_actor.metrics:
        eval_results[metric.name] = metric.result()

    logging.info(f"Evaluation: AverageReturn = {eval_results['AverageReturn']}")
    return policy_dir, eval_results


# def vis_eval_agent():
#     tf_eval_env = tf_py_environment.TFPyEnvironment(DorabotP2PVisEvalEnv())
#
#     saved_policy = tf.compat.v2.saved_model.load('policy_22000')
#
#     time_step = tf_eval_env.reset()
#     episode_return = 0.0
#
#     while not time_step.is_last():
#         action_step = saved_policy.action(time_step)
#         time_step = tf_eval_env.step(action_step.action)
#         print(time_step.reward)
#         episode_return += time_step.reward
#
#     print(f"Episode return: {episode_return}")

def upload_blob_from_memory(bucket_name, contents, destination_blob_name):
    """Uploads a file to the bucket."""

    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"

    # The contents to upload to the file
    # contents = "these are my contents"

    # The ID of your GCS object
    # destination_blob_name = "storage-object-name"

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)

    blob.upload_from_string(contents)

    print(f"Upload: Object {destination_blob_name} with contents {contents} is uploaded to {bucket_name}.")


def upload_blob(bucket_name, source_file_name, destination_blob_name):
    """Uploads a file to the bucket."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"
    # The path to your file to upload
    # source_file_name = "local/path/to/file"
    # The ID of your GCS object
    # destination_blob_name = "storage-object-name"

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)

    blob.upload_from_filename(source_file_name)

    print(f"Upload: File {source_file_name} uploaded to {destination_blob_name}.")


def download_blob_into_memory(bucket_name, blob_name):
    """Downloads a blob into memory."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"

    # The ID of your GCS object
    # blob_name = "storage-object-name"

    storage_client = storage.Client()

    bucket = storage_client.bucket(bucket_name)

    # Construct a client side representation of a blob.
    # Note `Bucket.blob` differs from `Bucket.get_blob` as it doesn't retrieve
    # any content from Google Cloud Storage. As we don't need additional data,
    # using `Bucket.blob` is preferred here.
    blob = bucket.blob(blob_name)
    contents = blob.download_as_string()

    print(f"Download: Object {blob_name} from bucket {bucket_name} is downloaded as the following string: {contents}.")

    return contents


def download_blob(bucket_name, source_blob_name, destination_file_name):
    """Downloads a blob from the bucket."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"

    # The ID of your GCS object
    # source_blob_name = "storage-object-name"

    # The path to which the file should be downloaded
    # destination_file_name = "local/path/to/file"

    storage_client = storage.Client()

    bucket = storage_client.bucket(bucket_name)

    # Construct a client side representation of a blob.
    # Note `Bucket.blob` differs from `Bucket.get_blob` as it doesn't retrieve
    # any content from Google Cloud Storage. As we don't need additional data,
    # using `Bucket.blob` is preferred here.
    blob = bucket.blob(source_blob_name)
    blob.download_to_filename(destination_file_name)

    print(
        f'Download: Object {source_blob_name} from bucket {bucket_name} is downloaded to local file {destination_file_name}.')


def list_blobs_with_prefix(bucket_name, prefix, delimiter=None):
    storage_client = storage.Client()

    blobs = storage_client.list_blobs(bucket_name, prefix=prefix, delimiter=delimiter)

    return [blob.name for blob in blobs]


def rename_blob(bucket_name, blob_name, new_name):
    """Renames a blob."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"
    # The ID of the GCS object to rename
    # blob_name = "your-object-name"
    # The new ID of the GCS object
    # new_name = "new-object-name"

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    new_blob = bucket.rename_blob(blob, new_name)

    print(f"Rename: Blob {blob.name} has been renamed to {new_blob.name}")


def delete_blob(bucket_name, blob_name):
    """Deletes a blob from the bucket."""
    # bucket_name = "your-bucket-name"
    # blob_name = "your-object-name"

    storage_client = storage.Client()

    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    blob.delete()

    print(f"Delete: Blob {blob_name} deleted.")


def create_zip_file(dirname, base_filename):
    return shutil.make_archive(base_filename, 'zip', dirname)


if __name__ == '__main__':
    episode_length_sec = 50
    num_agent_env = 4
    num_train_episode = (rl_config['train']['num_train_iteration'] * rl_config['train']['collect_step_per_iteration'] /
                         (episode_length_sec * 5))
    num_val_episode = (rl_config['train']['num_train_iteration'] * rl_config['train']['num_val_episode'] /
                       rl_config['train']['val_interval'])
    max_episode_needed = num_train_episode + num_val_episode + rl_config['train']['initial_collect_episode']

    gcloud_bucket_name = "independent-project-rl-content-bucket"
    DOCKER_ID = os.environ['DOCKER_ID']
    training_episode_config = {'episode_length_sec': episode_length_sec,
                               'max_episode': max_episode_needed,
                               'num_agent': num_agent_env}

    table_name = f"priority_table"
    # rate_limiter = reverb.rate_limiters.SampleToInsertRatio(samples_per_insert=2.0, min_size_to_sample=1996,
    #                                                         error_buffer=8.0)
    buffer_capacity = 1000000
    table = reverb.Table(table_name,
                         max_size=buffer_capacity,
                         sampler=reverb.selectors.Prioritized(priority_exponent=rl_config['buffer']['alpha']),
                         remover=reverb.selectors.Fifo(),
                         rate_limiter=reverb.rate_limiters.MinSize(rl_config['ddpg']['agent_batch_size']))
    reverb_server = reverb.Server([table])
    reverb_client = reverb.Client(f"localhost:{reverb_server.port}")

    while True:
        training_episode_config = {'episode_length_sec': episode_length_sec,
                                   'max_episode': max_episode_needed,
                                   'num_agent': num_agent_env}
        list_trials = list_blobs_with_prefix(gcloud_bucket_name, f"reward_trial/docker_{DOCKER_ID}_trial_")
        if not list_trials:
            list_trials = list_blobs_with_prefix(gcloud_bucket_name, f"reward_trial/trial_")

        if not list_trials:
            sleep(60)
            continue
        else:
            trial = list_trials[0]
            if trial[13] == 't':
                trial = trial[0:13] + f'docker_{DOCKER_ID}_' + trial[13:]
                try:
                    rename_blob(gcloud_bucket_name, list_trials[0], trial)
                except:
                    sleep(randint(10, 30))
                    continue
            else:
                logging.info('Reloading previous unfinished trial.')

            reward_param_json = json.loads(download_blob_into_memory(gcloud_bucket_name, trial))
            reward_param = np.array([reward_param_json['baseline'],
                                     reward_param_json['goal_distance'],
                                     reward_param_json['goal'],
                                     reward_param_json['turning'],
                                     reward_param_json['clearance'],
                                     reward_param_json['collision']], dtype=np.float32)

            final_policy_dir, policy_result = train_agent(training_episode_config,
                                                          reward_param=reward_param,
                                                          priority_alpha=rl_config['buffer']['alpha'],
                                                          actor_fc_param=[200, 200, 50],
                                                          critic_obs_fc_param=[200, 50],
                                                          critic_joint_fc_param=[50, 50])

            reverb_client.reset(table_name)

            upload_blob_from_memory(gcloud_bucket_name, str(policy_result['AverageReturn']),
                                    f"reward_trial/output_{reward_param_json['current_trial']}.txt")
            delete_blob(gcloud_bucket_name, trial)

            policy_zip_filename = create_zip_file(final_policy_dir,
                                                  os.path.join(tempfile.gettempdir(),
                                                               f"policy/exported_policy_trial_{reward_param_json['current_trial']}"))

            upload_blob(gcloud_bucket_name, policy_zip_filename,
                        f"reward_trial/output_policy/policy_trial_{reward_param_json['current_trial']}.zip")
            sleep(10)
            os.remove(policy_zip_filename)
